# SHAiiB'S EMPIRE COLLECTIONS — online store

A two-brand shop:
- SHAiiB'S EMPIRE COLLECTIONS (fashion, shoes, accessories)
- RIHANNA TOYS (separate 18+ department)

Includes public product listings, image/video upload, admin login, stock status, cart, WhatsApp ordering and OPay payment instructions.

## Important: this is the website source, not a hosted/live website yet
It must be deployed to a Node.js host with persistent storage and HTTPS before the owner can use it publicly. The app stores product data in `data/products.json` and uploaded media in `uploads/`; use a persistent disk/volume for both folders or products/media may be lost on redeploy.

## Setup
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Set these environment variables in your hosting dashboard:
   - `ADMIN_EMAIL=Shaiibrihanna@gmail.com`
   - `ADMIN_PASSWORD=` choose a strong private password (do not share it in chat)
   - `SESSION_SECRET=` use a long random secret
   - `WHATSAPP_NUMBER=2348168660487`
   - `PAYMENT_BANK=OPay`
   - `PAYMENT_ACCOUNT_NAME=Rehinat Shaiib`
   - `PAYMENT_ACCOUNT_NUMBER=8168660487`
   - `DATA_DIR=/persistent/data`
   - `UPLOAD_DIR=/persistent/uploads`
   - `NODE_ENV=production`
4. Attach a persistent disk and point DATA_DIR and UPLOAD_DIR to folders on it.
5. Set the start command to `npm start`, deploy, and open the site's HTTPS URL.
6. Tap **Admin**, sign in with the email and password you configured, and upload products.

## Security / operational notes
- Keep the admin password and session secret private.
- Use HTTPS. Do not accept payments based only on screenshots; verify transfers in the OPay account.
- Confirm the payment account details before launch.
- The app is a starter implementation. Before a high-volume commercial launch, add a managed database/object storage, automated backups, rate limiting, stronger admin audit logging, and privacy/terms pages.
- The store displays an 18+ label for Rihanna Toys. Restrict access and marketing in line with applicable local laws and hosting/payment provider rules.
